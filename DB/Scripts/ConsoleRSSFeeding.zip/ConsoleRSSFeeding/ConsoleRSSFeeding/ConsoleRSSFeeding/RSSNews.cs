﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleRSSFeeding
{
    public class RSSNews
    {
        public RSSNews()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        public string tit
        {
            get;
            set;
        }
        public string desc
        {
            get;
            set;
        }
        public string auth
        {
            get;
            set;
        }
        public string contentlink
        {
            get;
            set;
        }
        public string date
        {
            get;
            set;
        }
    }
}
