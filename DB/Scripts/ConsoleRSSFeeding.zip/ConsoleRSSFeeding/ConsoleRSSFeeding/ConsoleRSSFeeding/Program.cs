﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Configuration;
using System.Data;
using System.Globalization;
using System.Xml;
using System.ServiceModel.Syndication;
using System.Net;
using System.IO;
using System.Text.RegularExpressions;
using DA_SKORKEL;

namespace ConsoleRSSFeeding
{
    class Program
    {
        public static SqlConnection conn;

        public static object Validations { get; private set; }

        //string APIURL = ConfigurationManager.AppSettings["APIURL"];
        //string ISAPIURLACCESSED = ConfigurationManager.AppSettings["ISAPIURLACCESSED"];

        

        static void Main(string[] args)
        {
            DO_Scrl_APILogDetailsTbl objAPILogDO = new DO_Scrl_APILogDetailsTbl();
            DA_Scrl_APILogDetailsTbl objAPILogDA = new DA_Scrl_APILogDetailsTbl();
            string APIURL = ConfigurationManager.AppSettings["APIURL"];
            string ISAPIURLACCESSED = ConfigurationManager.AppSettings["ISAPIURLACCESSED"];
            string UserID = ConfigurationManager.AppSettings["UserID"];

            Console.WriteLine("Please wait for the operation of RSS feed...");
            DataTable dt = new DataTable();
            DataTable dtNews = new DataTable();
            conn = new SqlConnection();
            conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnstrRSSFeed"].ConnectionString;
            conn.Open();
            SqlDataAdapter da = new SqlDataAdapter();
            string sql = "Select ID,Link from NewsSources where Status='A'";
            da.SelectCommand = new SqlCommand(sql, conn);
            da.Fill(dt);
            conn.Close();

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string dr = dt.Rows[i]["Link"].ToString();
                //string dr = "https://www.thehindu.com/news/cities/Madurai/feeder/";
                //string dr = "https://www.policeone.com/law-enforcement-police-rss-feeds/news.xml";
                int SourceID = Convert.ToInt32(dt.Rows[i]["ID"]);

                bool IsValid = IsValidFeedUrl(dr);
                // do something with dr
                //var posts = GetFeeds(dr);

                //StringBuilder sb = new StringBuilder();
                //sb.Append("<p style='font-weight:larger'><b>Fetch RSS News</b></p>");
                //foreach (var item in posts.Take(10))
                if (IsValid == true)
                {
                    IEnumerable<RSSNews> posts = GetFeeds(dr);
                    int postsCount = posts.Count();
                    if (postsCount > 10)
                    {
                        postsCount = 10;
                    }
                    posts = posts.Take(postsCount);
                    StringBuilder sb = new StringBuilder();
                    sb.Append("<p style='font-weight:larger'><b>Fetch RSS News</b></p>");
                    //for (var item = 0; item < posts.Count; item++)
                    foreach (var item in posts)
                    {
                        sb.Append("<b>Title: </b>" + item.tit);
                        sb.Append("<br />");
                        sb.Append("<b>Description: </b>" + item.desc);
                        sb.Append("<br />");
                        sb.Append("<b>Article Link: </b><a target='_blank' href='" + item.contentlink + "'>" + item.contentlink + "</a>");
                        sb.Append("<br />");
                        sb.Append("<b>Published Date: </b>" + item.date);
                        sb.Append("<br />");
                        //sb.Append("<b>Author: </b>" + item.auth);
                        //sb.Append("<br />");
                        sb.Append("------------------------------------------------------------------------------------------------------------");
                        sb.Append("<br />");
                        string description = item.desc;
                        string Source_link = item.contentlink;
                        string Title = item.tit;
                        DateTime Published_Timestamp = DateTime.Now;

                        SqlCommand cmd;
                        int intNewsOutId = 0;
                        cmd = new SqlCommand("Scrl_NewsListing", conn);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@FlagNo", SqlDbType.Int).Value = 14;
                        cmd.Parameters.Add("@strTitle", SqlDbType.VarChar, 2000).Value = Title;
                        cmd.Parameters.Add("@strLink", SqlDbType.VarChar, 200).Value = Source_link;
                        cmd.Parameters.Add("@strContent", SqlDbType.VarChar, 100000000).Value = description;
                        cmd.Parameters.Add("@publishTimestamp", SqlDbType.DateTime).Value = Published_Timestamp;
                        cmd.Parameters.Add("@SourceID", SqlDbType.Int).Value = SourceID;
                        conn.Open();
                        //cmd.ExecuteReader();                        
                        intNewsOutId = Convert.ToInt32(cmd.ExecuteScalar());
                        conn.Close();
                        if (intNewsOutId != 0)
                        {
                            //dtNews = objDANewsListing.GetDataTable(objDONewsListing, DA_Scrl_UserNewsListing.NewsListing.SingleNewsRecord);

                            conn.Open();
                            SqlDataAdapter daNews = new SqlDataAdapter();
                            dtNews.Clear();

                            daNews.SelectCommand = new SqlCommand("Scrl_NewsListing", conn);
                            daNews.SelectCommand.CommandType = CommandType.StoredProcedure;

                            daNews.SelectCommand.Parameters.Add("@FlagNo", SqlDbType.Int).Value = 8;
                            daNews.SelectCommand.Parameters.Add("@ID", SqlDbType.Int).Value = intNewsOutId;

                            daNews.Fill(dtNews);
                            conn.Close();

                            if (ISAPIURLACCESSED != "0")
                            {
                                try
                                {
                                    string detail = null;
                                    string noHTML = null;
                                    string detail_noHTML = null;

                                    detail = Convert.ToString(dtNews.Rows[0]["Content"]);
                                    noHTML = Regex.Replace(detail, @"<[^>]+>|&nbsp;", "").Trim();
                                    detail_noHTML = Regex.Replace(noHTML, @"\s{2,}", " ");

                                    StringBuilder url = new StringBuilder();
                                    url.Append(APIURL);
                                    url.Append("addNews?");
                                    url.Append("newsId=");
                                    url.Append(intNewsOutId);
                                    url.Append("&userId=");
                                    url.Append(UserID);
                                    url.Append("&dateOfSubmission=");
                                    url.Append(DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond);
                                    url.Append("&title=");
                                    url.Append(dtNews.Rows[0]["Title"]);
                                    url.Append("&description=");
                                    url.Append(detail_noHTML);
                                    url.Append("&source=");
                                    url.Append(dtNews.Rows[0]["Source_link"]);
                                    url.Append("&newsCategory=");
                                    url.Append(dtNews.Rows[0]["Type"]);
                                    url.Append("&documentId=" + null);

                                    HttpWebRequest myRequest1 = (HttpWebRequest)WebRequest.Create(url.ToString());
                                    myRequest1.Method = "GET";
                                    WebResponse myResponse1 = myRequest1.GetResponse();
                                    StreamReader sr = new StreamReader(myResponse1.GetResponseStream(), System.Text.Encoding.UTF8);
                                    String result = sr.ReadToEnd();

                                    objAPILogDO.strURL = url.ToString();
                                    objAPILogDO.strAPIType = "Add News";
                                    objAPILogDO.strResponse = result;
                                    objAPILogDO.strIPAddress = "::1";
                                    objAPILogDO.intAddedBy = Convert.ToInt32(UserID);
                                    conn.Open();
                                    //objAPILogDA.AddEditDel_Scrl_APILogDetailsTbl(objAPILogDO, DA_Scrl_APILogDetailsTbl.Scrl_APILogDetailsTbl.Insert);

                                    SqlCommand APIcmd;
                                    APIcmd = new SqlCommand("SP_Scrl_APILogDetailsTbl", conn);
                                    APIcmd.CommandType = CommandType.StoredProcedure;
                                    APIcmd.Parameters.Add("@FlagNo", SqlDbType.Int).Value = 1;
                                    //APIcmd.Parameters.Add("@intAPILogId", SqlDbType.Int).Value = ObjScrl.intAPILogId;
                                    APIcmd.Parameters.Add("@strAPIType", SqlDbType.VarChar, 50).Value = objAPILogDO.strAPIType;
                                    APIcmd.Parameters.Add("@strURL", SqlDbType.VarChar, 500).Value = objAPILogDO.strURL;
                                    APIcmd.Parameters.Add("@strResponse", SqlDbType.VarChar, 8000).Value = objAPILogDO.strResponse;
                                    APIcmd.Parameters.Add("@intAddedBy", SqlDbType.Int).Value = objAPILogDO.intAddedBy;
                                    APIcmd.Parameters.Add("@intModifiedBy", SqlDbType.Int).Value = objAPILogDO.intAddedBy;
                                    APIcmd.Parameters.Add("@strIPAddress", SqlDbType.VarChar, 20).Value = objAPILogDO.strIPAddress;

                                    APIcmd.ExecuteNonQuery();
                                    conn.Close();
                                }
                                catch (Exception ex)
                                { }
                            }
                        }

                        
                    }
                }
                else
                {
                    Console.WriteLine("Invalid URL...");
                    //Console.ReadKey();
                }
                //Console.Write(sb);
                //Console.ReadKey();
            }            
        }

        public static bool IsValidFeedUrl(string url)
        {
            bool isValid = true;
            try
            {
                XmlReader reader = XmlReader.Create(url);
                Rss20FeedFormatter formatter = new Rss20FeedFormatter();
                formatter.ReadFrom(reader);
                reader.Close();
            }
            catch
            {
                isValid = false;
            }

            return isValid;
        }

        public static IEnumerable<RSSNews> GetFeeds(string url)
        {
            XDocument rssfeedxml;
            XNamespace namespaceName = "http://www.w3.org/2005/Atom";
            rssfeedxml = XDocument.Load(url);

            StringBuilder rssContent = new StringBuilder();

            var list = (from descendant in rssfeedxml.Descendants("item")

                        //Response.Write(list);  
                        select new RSSNews
                        {
                            tit = descendant.Element("title").Value,
                            desc = descendant.Element("description").Value,
                            contentlink = descendant.Element("link").Value,
                            date = descendant.Element("pubDate").Value
                            //auth = descendant.Element("author").Value
                        });
            return list.ToList();
        }
    }
}
